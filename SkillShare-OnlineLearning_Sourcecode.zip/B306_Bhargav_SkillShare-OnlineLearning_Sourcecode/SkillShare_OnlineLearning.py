import tkinter as tk
from tkinter import messagebox, ttk, simpledialog
import pyodbc
from datetime import datetime

# Database Connection
conn = pyodbc.connect(
    'DRIVER={SQL Server};'
    "SERVER=DESKTOP-V52JO9J\SQLEXPRESS;"
    "DATABASE=OnlineLearning;"
    "Trusted_Connection=yes;"
)
cursor = conn.cursor()

class LearningApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SkillShare-OnlineLearning")
        self.root.geometry("400x400")

        tk.Label(root, text="Email:").pack()
        self.email_entry = tk.Entry(root)
        self.email_entry.pack()

        tk.Label(root, text="Password:").pack()
        self.password_entry = tk.Entry(root, show="*")
        self.password_entry.pack()

        tk.Button(root, text="Login", command=self.login).pack()
        tk.Button(root, text="Register", command=self.register).pack()

    def login(self):
        email = self.email_entry.get()
        password = self.password_entry.get()
        cursor.execute("SELECT UserID, Role, JoinDate FROM Users WHERE Email=? AND Password=?", (email, password))
        user = cursor.fetchone()
        if user:
            user_id, role, join_date = user
            self.open_dashboard(user_id, role)
        else:
            messagebox.showerror("Error", "Invalid credentials")

    def register(self):
        register_window = tk.Toplevel(self.root)
        register_window.title("Register")
        register_window.geometry("400x400")

        tk.Label(register_window, text="Name:").pack()
        name_entry = tk.Entry(register_window)
        name_entry.pack()

        tk.Label(register_window, text="Email:").pack()
        email_entry = tk.Entry(register_window)
        email_entry.pack()

        tk.Label(register_window, text="Password:").pack()
        password_entry = tk.Entry(register_window, show="*")
        password_entry.pack()

        tk.Label(register_window, text="Role:").pack()
        role_combobox = ttk.Combobox(register_window, values=["Student", "Instructor", "Admin"])
        role_combobox.pack()

        def submit_registration():
            cursor.execute("INSERT INTO Users (Name, Email, Password, Role, JoinDate) VALUES (?, ?, ?, ?, ?)",
                           (name_entry.get(), email_entry.get(), password_entry.get(), role_combobox.get(), datetime.now()))
            conn.commit()
            messagebox.showinfo("Success", "Registration successful! You have a free trial for 7 days.")
            register_window.destroy()

        tk.Button(register_window, text="Register", command=submit_registration).pack()

    def open_dashboard(self, user_id, role):
        dashboard_window = tk.Toplevel(self.root)
        dashboard_window.title("Dashboard")
        dashboard_window.geometry("600x600")

        tk.Label(dashboard_window, text=f"Welcome {role}", font=("Arial", 14)).pack()

        if role == 'Student':
            self.show_student_dashboard(dashboard_window, user_id)
        elif role == 'Instructor':
            self.show_instructor_dashboard(dashboard_window, user_id)
        elif role == 'Admin':
            self.show_admin_dashboard(dashboard_window)

    def show_student_dashboard(self, dashboard_window, user_id):
        tk.Label(dashboard_window, text="Available Courses:").pack()
        courses_listbox = tk.Listbox(dashboard_window)
        courses_listbox.pack()
        
        cursor.execute("SELECT CourseID, Title FROM Courses")
        courses = cursor.fetchall()
        
        for course in courses:
            courses_listbox.insert(tk.END, f"{course[0]} - {course[1]}")

        def enroll_course():
            selected = courses_listbox.curselection()
            if selected:
                course_id = courses[selected[0]][0]
                cursor.execute("INSERT INTO Enrollments (UserID, CourseID, EnrollDate) VALUES (?, ?, ?)", (user_id, course_id, datetime.now()))
                conn.commit()
                messagebox.showinfo("Success", "Enrolled in course successfully!")
            else:
                messagebox.showwarning("Warning", "Please select a course to enroll.")

        tk.Button(dashboard_window, text="Enroll", command=enroll_course).pack()

        tk.Label(dashboard_window, text="My Courses:").pack()
        enrolled_listbox = tk.Listbox(dashboard_window)
        enrolled_listbox.pack()
        
        cursor.execute("SELECT Courses.Title FROM Courses INNER JOIN Enrollments ON Courses.CourseID = Enrollments.CourseID WHERE Enrollments.UserID=?", (user_id,))
        enrolled_courses = cursor.fetchall()
        
        for course in enrolled_courses:
            enrolled_listbox.insert(tk.END, course[0])

        tk.Label(dashboard_window, text="My Assignments:").pack()
        assignments_listbox = tk.Listbox(dashboard_window)
        assignments_listbox.pack()
        
        cursor.execute("SELECT Assignments.Title FROM Assignments INNER JOIN Enrollments ON Assignments.CourseID = Enrollments.CourseID WHERE Enrollments.UserID=?", (user_id,))
        assignments = cursor.fetchall()
        
        for assignment in assignments:
            assignments_listbox.insert(tk.END, assignment[0])

    def show_instructor_dashboard(self, dashboard_window, instructor_id):
        tk.Button(dashboard_window, text="Add Course", command=lambda: self.add_course(instructor_id)).pack()
        tk.Button(dashboard_window, text="Upload Lecture", command=lambda: self.upload_lecture(instructor_id)).pack()
        tk.Button(dashboard_window, text="Create Assignment", command=lambda: self.create_assignment(instructor_id)).pack()
        tk.Button(dashboard_window, text="Create Quiz", command=lambda: self.create_quiz(instructor_id)).pack()

    def show_admin_dashboard(self, dashboard_window):
        tk.Label(dashboard_window, text="Admin Panel", font=("Arial", 14)).pack()
        tk.Button(dashboard_window, text="View Users", command=self.view_users).pack()
        tk.Button(dashboard_window, text="Remove User", command=self.remove_user).pack()
        tk.Button(dashboard_window, text="Remove Course", command=self.remove_course).pack()

    def view_users(self):
        cursor.execute("SELECT UserID, Name, Email, Role FROM Users")
        users = cursor.fetchall()
        user_list = "\n".join([f"{user[0]} - {user[1]} ({user[2]}) - {user[3]}" for user in users])
        messagebox.showinfo("Users", user_list)

    def remove_user(self):
        user_id = simpledialog.askinteger("Remove User", "Enter User ID to remove:")
        if user_id:
            cursor.execute("DELETE FROM Users WHERE UserID=?", (user_id,))
            conn.commit()
            messagebox.showinfo("Success", "User removed successfully!")

    def remove_course(self):
        course_id = simpledialog.askinteger("Remove Course", "Enter Course ID to remove:")
        if course_id:
            cursor.execute("DELETE FROM Courses WHERE CourseID=?", (course_id,))
            conn.commit()
            messagebox.showinfo("Success", "Course removed successfully!")

    def add_course(self, instructor_id):
        add_win = tk.Toplevel(self.root)
        add_win.title("Add Course")
        add_win.geometry("400x300")

        tk.Label(add_win, text="Course Title:").pack()
        title_entry = tk.Entry(add_win)
        title_entry.pack()

        tk.Label(add_win, text="Description:").pack()
        desc_entry = tk.Text(add_win, height=5)
        desc_entry.pack()

        tk.Label(add_win, text="Price:").pack()
        price_entry = tk.Entry(add_win)
        price_entry.pack()

        def submit_course():
            cursor.execute("INSERT INTO Courses (Title, Description, InstructorID, Price) VALUES (?, ?, ?, ?)",
                           (title_entry.get(), desc_entry.get("1.0", tk.END), instructor_id, price_entry.get()))
            conn.commit()
            messagebox.showinfo("Success", "Course added successfully!")
            add_win.destroy()

        tk.Button(add_win, text="Add Course", command=submit_course).pack()

    def upload_lecture(self, instructor_id):
        upload_win = tk.Toplevel(self.root)
        upload_win.title("Upload Lecture")
        upload_win.geometry("400x300")

        tk.Label(upload_win, text="Select Course:").pack()
        course_combobox = ttk.Combobox(upload_win)
        course_combobox.pack()

        cursor.execute("SELECT CourseID, Title FROM Courses WHERE InstructorID=?", (instructor_id,))
        courses = cursor.fetchall()
        course_dict = {f"{c[1]} (ID:{c[0]})": c[0] for c in courses}
        course_combobox['values'] = list(course_dict.keys())

        tk.Label(upload_win, text="Lecture Title:").pack()
        title_entry = tk.Entry(upload_win)
        title_entry.pack()

        tk.Label(upload_win, text="Video URL:").pack()
        url_entry = tk.Entry(upload_win)
        url_entry.pack()

        def submit_lecture():
            course_id = course_dict[course_combobox.get()]
            cursor.execute("INSERT INTO Lectures (CourseID, Title, VideoURL, UploadDate) VALUES (?, ?, ?, ?)",
                           (course_id, title_entry.get(), url_entry.get(), datetime.now()))
            conn.commit()
            messagebox.showinfo("Success", "Lecture uploaded!")
            upload_win.destroy()

        tk.Button(upload_win, text="Upload", command=submit_lecture).pack()

    def create_assignment(self, instructor_id):
        assign_win = tk.Toplevel(self.root)
        assign_win.title("Create Assignment")
        assign_win.geometry("400x300")

        tk.Label(assign_win, text="Select Course:").pack()
        course_combobox = ttk.Combobox(assign_win)
        course_combobox.pack()

        cursor.execute("SELECT CourseID, Title FROM Courses WHERE InstructorID=?", (instructor_id,))
        courses = cursor.fetchall()
        course_dict = {f"{c[1]} (ID:{c[0]})": c[0] for c in courses}
        course_combobox['values'] = list(course_dict.keys())

        tk.Label(assign_win, text="Assignment Title:").pack()
        title_entry = tk.Entry(assign_win)
        title_entry.pack()

        tk.Label(assign_win, text="Deadline (YYYY-MM-DD):").pack()
        deadline_entry = tk.Entry(assign_win)
        deadline_entry.pack()

        tk.Label(assign_win, text="Max Marks:").pack()
        marks_entry = tk.Entry(assign_win)
        marks_entry.pack()

        def submit_assignment():
            course_id = course_dict[course_combobox.get()]
            cursor.execute("INSERT INTO Assignments (CourseID, Title, Deadline, MaxMarks) VALUES (?, ?, ?, ?)",
                           (course_id, title_entry.get(), deadline_entry.get(), marks_entry.get()))
            conn.commit()
            messagebox.showinfo("Success", "Assignment created!")
            assign_win.destroy()

        tk.Button(assign_win, text="Create", command=submit_assignment).pack()

    def create_quiz(self, instructor_id):
        quiz_win = tk.Toplevel(self.root)
        quiz_win.title("Create Quiz")
        quiz_win.geometry("400x300")

        tk.Label(quiz_win, text="Select Course:").pack()
        course_combobox = ttk.Combobox(quiz_win)
        course_combobox.pack()

        cursor.execute("SELECT CourseID, Title FROM Courses WHERE InstructorID=?", (instructor_id,))
        courses = cursor.fetchall()
        course_dict = {f"{c[1]} (ID:{c[0]})": c[0] for c in courses}
        course_combobox['values'] = list(course_dict.keys())

        tk.Label(quiz_win, text="Quiz Title:").pack()
        title_entry = tk.Entry(quiz_win)
        title_entry.pack()

        tk.Label(quiz_win, text="Total Marks:").pack()
        marks_entry = tk.Entry(quiz_win)
        marks_entry.pack()

        def submit_quiz():
            course_id = course_dict[course_combobox.get()]
            cursor.execute("INSERT INTO Quizzes (CourseID, Title, TotalMarks) VALUES (?, ?, ?)",
                           (course_id, title_entry.get(), marks_entry.get()))
            conn.commit()
            messagebox.showinfo("Success", "Quiz created!")
            quiz_win.destroy()

        tk.Button(quiz_win, text="Create", command=submit_quiz).pack()

# Run the app
root = tk.Tk()
app = LearningApp(root)
root.mainloop()

conn.close()
