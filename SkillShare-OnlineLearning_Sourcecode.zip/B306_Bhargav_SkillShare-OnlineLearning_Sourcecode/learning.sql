CREATE DATABASE OnlineLearning;
USE OnlineLearning;
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) UNIQUE NOT NULL,
    Password NVARCHAR(255) NOT NULL,
    Role NVARCHAR(50) CHECK (Role IN ('Student', 'Instructor', 'Admin')),
    JoinDate DATETIME DEFAULT GETDATE()
);

CREATE TABLE Courses (
    CourseID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(255) NOT NULL,
    Description TEXT,
    InstructorID INT,
    Price DECIMAL(10,2) DEFAULT 0,
    FOREIGN KEY (InstructorID) REFERENCES Users(UserID) ON DELETE SET NULL
);
CREATE TABLE Enrollments (
    EnrollID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT,
    CourseID INT,
    EnrollDate DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES Users(UserID) ON DELETE CASCADE,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE CASCADE
);
CREATE TABLE Lectures (
    LectureID INT IDENTITY(1,1) PRIMARY KEY,
    CourseID INT,
    Title NVARCHAR(255) NOT NULL,
    VideoURL NVARCHAR(500),
    UploadDate DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE CASCADE
);
CREATE TABLE Quizzes (
    QuizID INT IDENTITY(1,1) PRIMARY KEY,
    CourseID INT,
    Title NVARCHAR(255),
    TotalMarks INT,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE CASCADE
);
CREATE TABLE QuizAttempts (
    AttemptID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT,
    QuizID INT,
    Score INT,
    AttemptDate DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES Users(UserID) ON DELETE CASCADE,
    FOREIGN KEY (QuizID) REFERENCES Quizzes(QuizID) ON DELETE CASCADE
);
CREATE TABLE Assignments (
    AssignmentID INT IDENTITY(1,1) PRIMARY KEY,
    CourseID INT,
    Title NVARCHAR(255) NOT NULL,
    Deadline DATETIME,
    MaxMarks INT,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE CASCADE
);
CREATE TABLE Payments (
    PaymentID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT,
    CourseID INT,
    Amount DECIMAL(10,2),
    Status NVARCHAR(50) CHECK (Status IN ('Pending', 'Completed', 'Failed')),
    FOREIGN KEY (UserID) REFERENCES Users(UserID) ON DELETE CASCADE,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE CASCADE
);
CREATE TABLE Discussions (
    PostID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT,
    CourseID INT,
    Message TEXT,
    PostDate DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES Users(UserID) ON DELETE CASCADE,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE CASCADE
);

select * from users;
select * from Courses;
select * from Enrollments;
select * from Lectures;
select * from Quizzes;
select * from Assignments;


